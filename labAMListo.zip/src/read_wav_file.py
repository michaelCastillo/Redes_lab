

#Script para la lectura de un archivo .wav en python 3

import os
##Bloque principal##
#file = open('../static/mario_doublejump.wav','rb')
